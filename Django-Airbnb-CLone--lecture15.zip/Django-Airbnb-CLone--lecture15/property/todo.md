- navbar linkes 
- add property 


- footer linkes 
- blog
- search 
- rating
