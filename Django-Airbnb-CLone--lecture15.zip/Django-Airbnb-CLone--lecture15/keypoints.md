- payment [paypal - visacard - fawery]
- mobile app [ mobile app - api]
- dashbaord
- real time [vue js]
- tasks - automate 
- chating 



----------------------------------------
 - dashboard
 - reports 
 - payment
 - js framework 


 - 4000$
 - 4000$
 - 3 month


angular 
react 
vue js 