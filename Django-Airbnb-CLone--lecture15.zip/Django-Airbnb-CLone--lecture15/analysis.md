- main categories [reaturant - hotel - shopping]
- property : 
    - title .
    - price .
    - rating
    - description  .
    - place  .
    - main image .
    - images  .
    - category .
    - book form 



- about : 
    about:
        - vision
        - mission 
        - goals 

    FAQ :
        - title
        - description 


- articles : 
    - post : 
        - title
        - descrption 
        -category
        - image
        - created at
        - comments
        - authot


- contact form 
    - name
    - email 
    - subject 
    - message

contact information : 
    - email 
    - address
    - mobile number